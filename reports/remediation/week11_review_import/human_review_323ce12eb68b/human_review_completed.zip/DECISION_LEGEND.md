# Reviewer Decision Legend

| Decision | Meaning |
| --- | --- |
| `accept` | Evidence directly supports the value and the field semantics are correct. |
| `accept_with_conditions` | Evidence supports the value only within explicit tier, Region, market, or usage conditions. |
| `reject_reparse` | The value, column selection, or semantic field mapping is incorrect or incomplete and must be reparsed. |
| `defer` | The exported evidence lacks enough scope or depends on unresolved upstream data. |

These files are review outputs only. They do not update the database and are not customer-facing approvals.
