# 人工审核结果摘要

## 结论

本次审核仅依据上传文件中的 `source_url`、`locator`、`excerpt`、原始值和归一化值进行。
审核结果不能直接视为客户可用事实，仍需由项目脚本回写数据库、重跑归一化与可比性计算。

## 审核数量

| 文件 | 行数 |
| --- | ---: |
| ReviewItem | 1441 |
| Normalized pending | 678 |
| Comparability blockers | 103 |
| Scope mismatch | 0 |
| Data quality issues | 0 |

## 决策统计

### ReviewItem

{
  "accept": 23,
  "reject_reparse": 1411,
  "defer": 3,
  "accept_with_conditions": 4
}

### Normalized pending

{
  "reject_reparse": 678
}

### Comparability blockers

{
  "accept_with_conditions": 101,
  "defer": 2
}

## 关键发现

1. **678条 AWS EC2 内存归一化记录存在列错位**：`✗ No` 是布尔能力列，不是内存。每条审核备注中已给出同一官方表格行中的正确内存值。
2. **671条 AWS EC2 CPU架构记录字段错配**：当前值实际是处理器型号，不能作为 `cpu_architecture`。
3. **48条阿里云可用区代码被写入 `zone.name`**：已在备注中给出对应本地名称，应拆分为 `zone.code` 与 `zone.name`。
4. **SLA误提取**：阿里云OSS的 `100%` 来自计算公式；AWS S3的 `99.9%` 当前定位是补偿阈值，均不能直接批准为服务承诺值。
5. **对象存储范围问题**：取回时间和冗余方式必须绑定具体存储类别、Region或冗余变体，不能提升为产品级统一事实。
6. **103条可比性阻断记录中，101条保留为有效的保守判断**；2条依赖错误的AWS内存归一化记录，保持 deferred，待重解析后重新计算。

## 决策值

- `accept`：证据直接支持，字段语义正确。
- `accept_with_conditions`：仅在明确的存储类别、Region或市场范围下成立。
- `reject_reparse`：字段或值错误/不完整，需要重解析。
- `defer`：现有导出缺少必要范围或上游数据尚未修复。

## 下一步

1. 先修复 AWS EC2 表格列映射并重建内存与CPU架构归一化记录。
2. 拆分阿里云 `zone.code` 与 `zone.name`。
3. 为对象存储补齐 `service_tier` 和 Region 范围。
4. 重新生成 ComparabilityAssessment。
5. 将本次审核决定通过受控脚本回写数据库，并保留审核历史。
